package com.sagar.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcJpa3MayApplicationTests {

	@Test
	void contextLoads() {
	}

}
