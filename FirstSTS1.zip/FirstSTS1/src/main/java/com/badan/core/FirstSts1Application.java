package com.badan.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.badan.core.pojo.Address;
import com.badan.core.pojo.Student;

@SpringBootApplication
public class FirstSts1Application {

	public static void main(String[] args) {
		SpringApplication.run(FirstSts1Application.class, args);
		
		Address ad=new Address();
		ad.sethNO(420);
		ad.sethName("Komal Resdiency");
		ad.setPhone(8307152871L);
		
		Student st=new Student();
		st.setAddress(ad);
		st.setNo(101);
		st.setName("Badan Singh");
		
		System.out.println("no=> "+st.getNo());
		System.out.println("name=> "+st.getName());
		System.out.println("name=> "+st.getAddress());
		//System.out.println(" To String=> "+st);
		System.out.println("Date Is=> "+st.getDate());
		
	}

}
