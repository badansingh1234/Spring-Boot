package com.badan.rest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.badan.rest.model.Book;
import com.badan.rest.repository.BookRepository;

@RestController
public class BookController {

	@Autowired
	private BookRepository bookRepository;
	
	@RequestMapping("/welcome")
	public String welcome()
	{
		return "Your Most Welcome...";
	}
	//add book ....
	@PostMapping("/addbook")
	public String addBook(@RequestBody Book book)
	{
		bookRepository.save(book);
		return "Book Added Sucessfully...";		
	}
	
	//findAllbook
	@GetMapping("/findallbook")
	public List<Book> findAllBook()
	{
		return bookRepository.findAll();
	}
	//findBook 
	@GetMapping("/findbook/{id}")
	public Book findBook(@PathVariable Integer id)
	{
		Book book=new Book();
		Optional<Book> o = bookRepository.findById(id);
		if(!o.isEmpty())
		{
			book=o.get();
		}
		return book;
	}
	//delete book	
	@DeleteMapping("/deletebook")
	public String deleteBook(@RequestParam Integer id)
	{
		String msg="Book Not Found....";
		Book book=findBook(id);
		if(book.getId()!=null)
		{
			bookRepository.delete(book);
			msg="Book Delete Sucessfully...";
		}
		return msg;
	}
	//update book
	@PutMapping("/updatebook")
	public Book updateBook(@RequestBody Book book)
	{
		Book myBook=findBook(book.getId());
		if(myBook.getId()==null)
		{
			return myBook;
		}
		return bookRepository.save(book);
	}
	
}
