package com.badan.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.badan.web.model.User;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	
	@RequestMapping("user")
	public String user(@ModelAttribute User user)
	{
		return "user";
	}
	
	/*@RequestMapping("user")
	public String user(@RequestParam("userName") String userName,@RequestParam("userPassword") String userPassword,Model m)
	{
		User user=new User();
		user.setUserName(userName);
		user.setUserPassword(userPassword);
		m.addAttribute("user", user);
		return "user";
	}*/
}
