package com.badan.aop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AopRestExample1Application {

	public static void main(String[] args) {
		SpringApplication.run(AopRestExample1Application.class, args);
	}

}
