package com.badan.demo.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.badan.demo.model.Empl;

public interface EmpRepositary extends JpaRepository<Empl, Integer>{

}
