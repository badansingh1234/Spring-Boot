package com.badan.core.pojo;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Student {
	private Integer no;
	private String name;
	
	@Autowired
	private Address address;
	
	@Autowired
	private Date date;
	
	public Date getDate() {
		return date;
	}
//	public void setDate(Date date) {
//		this.date = date;
//	}
//	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Integer getNo() {
		return no;
	}
	public void setNo(Integer no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Student() {	}

	@Override
	public String toString() {
		return "Student [no=" + no + ", name=" + name + ", address=" + address + ", date=" + date + "]";
	}
	
}
