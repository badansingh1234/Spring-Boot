package com.badan.core.opration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class BulbService {
	@Autowired  // bytype
	@Qualifier("lg") //byname
	public Bulb bulb;

	public Bulb getBulb() {
		return bulb;
	}
	public void setBulb(Bulb bulb) {
		this.bulb = bulb;
	}
	public String askBulb()
	{
		return bulb.getBulb();
	}
}
