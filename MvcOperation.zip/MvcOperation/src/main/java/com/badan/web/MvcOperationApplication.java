package com.badan.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcOperationApplication.class, args);
	}

}
