package com.badan.aop.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyAspect {

	@Before("execution(public String com.badan.aop.controller.MyController.findAll())")
	public void input()
	{
		System.out.println("Some Input Process... ");
	}
	
	/*
	 * @After("execution(public * com.badan.aop.controller.MyController.findAll())")
	 * public void output() {
	 * System.out.println("Some OutPut process.And exception time working.."); }
	 * 
	 * @AfterReturning("execution(public * com.badan.aop.controller.MyController.findAll())"
	 * ) public void outputException() {
	 * System.out.println("Exception time not Working..this annatation."); }
	 */
	
	@AfterThrowing("execution(public * com.badan.aop.controller.MyController.findAll())")
	public void output1()
	{
		System.out.println("Exception Handler ....");
	}
}
