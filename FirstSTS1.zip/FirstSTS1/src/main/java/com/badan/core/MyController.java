package com.badan.core;

import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;

import com.badan.core.pojo.Student;

@Controller
@ComponentScan(basePackages = "com.badan.core.*")
public class MyController {
	@Bean
	public String add()
	{
		System.out.println("Hello Word");
		return "Hello World";
	}
	
	@Bean
	public Date date()
	{
		return new Date();
	}
	
//	@Bean
//	public Student student()
//	{
//		return new Student();
//	}
	
}
