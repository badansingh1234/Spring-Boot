package com.badan.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSts1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
