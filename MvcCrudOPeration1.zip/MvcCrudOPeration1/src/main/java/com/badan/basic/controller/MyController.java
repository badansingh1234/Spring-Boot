package com.badan.basic.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.badan.basic.Repository.PersonRepository;
import com.badan.basic.model.Person;

@Controller
public class MyController {
	
	@Autowired
	private PersonRepository personRepository;

	@RequestMapping("/") 
	public String home() {
		return "index";
	}
	@GetMapping("add") 
	public String add() {
		return "add";
	}
	@PostMapping("addRecord") 
	public String addRecord(@ModelAttribute Person person, Model m) {
		personRepository.save(person);
		m.addAttribute("msg", "save data sucessfully....");
		return "add";
	}

	@GetMapping("update")
	public String update() {
		return "update";
	}
	@PostMapping("updateRecord")
	public String updateRecord(@ModelAttribute Person person, Model m) {
		Optional<Person> o = personRepository.findById(person.getNo());
		if (!o.isEmpty()) {
			Person p = o.get();
			p.setName(person.getName());
			p.setSalary(person.getSalary());
			personRepository.save(p);
			m.addAttribute("msg", "data updete sucessfully...");
		} 
		else {
			m.addAttribute("msg", "Not Record Found...");
		}
		return "update";
	}

	@GetMapping("delete")
	public String delete() {
		return "delete";
	}
	@PostMapping("deleteRecord")
	public String deleteRecord(@ModelAttribute Person person, Model m) 
	{
		Optional<Person> o = personRepository.findById(person.getNo());
		if(!o.isEmpty()) 
		{
			Person p = o.get();
			personRepository.delete(p);
			m.addAttribute("msg", " Record delete sucessfully..");
		}
		else {
			m.addAttribute("msg","Record Not Found...");
		}
		return "delete";
	}
	
	@GetMapping("find")
	public String find()
	{
		return "find";
	}
	@PostMapping("findRecord")
	public String findRecord(@ModelAttribute Person person,Model m)
	{
		Optional<Person> o=personRepository.findById(person.getNo());
		if(!o.isEmpty())
		{
			Person p=o.get();
			m.addAttribute("msg",p);
		}
		else
		{
			m.addAttribute("msg","Record Not Found...");
		}
		return "find";
	}
	
	@GetMapping("findAll")
	public String findAll()
	{
		return "findAll";
	}
	@PostMapping("findAllRecord")
	public String findAllRecord(@ModelAttribute Person person,Model m)
	{
		List<Person> list=personRepository.findAll();
		Iterator<Person> itr=list.iterator();
		while(itr.hasNext())
		{
			Person p=itr.next();
			m.addAttribute("msg", p);
		}
		return "findAll";
	}
}
