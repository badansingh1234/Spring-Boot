package com.badan.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DefaultSecurity1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
