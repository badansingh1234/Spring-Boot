package com.badan.core.opration;

import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value="prototype")
@Primary
public class SuryaBulb implements Bulb {

	@Override
	public String getBulb() {
		return "Surya Bulb";
	}

}
