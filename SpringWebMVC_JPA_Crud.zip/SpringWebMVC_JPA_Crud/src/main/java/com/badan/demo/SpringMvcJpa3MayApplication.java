package com.badan.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcJpa3MayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcJpa3MayApplication.class, args);
	}

}
