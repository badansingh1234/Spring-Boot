package com.badan.aop.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home()
	{
		System.out.println(12/0);
		return "index";
	}
	
	@RequestMapping("/findAll")
	public String findAll()
	{
		return "findAll";
	}
}
