package com.badan.web;


import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home()
	{
		return "index.jsp";
	}
	
	@RequestMapping("/add")
	public String add(HttpServletRequest req)
	{
		String num1=req.getParameter("num1");
		String num2=req.getParameter("num2");
		int a=Integer.parseInt(num1);
		int b=Integer.parseInt(num2);
		int num3=a+b;
		HttpSession s=req.getSession();
		s.setAttribute("num3", num3);
		return "add.jsp";
	}
}
