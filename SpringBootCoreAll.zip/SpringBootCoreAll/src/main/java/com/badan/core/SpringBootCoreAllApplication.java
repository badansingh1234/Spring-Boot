package com.badan.core;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.badan.core.opration.BulbService;
import com.badan.core.opration.LgBulb;
import com.badan.core.opration.SuryaBulb;

@SpringBootApplication
public class SpringBootCoreAllApplication {

	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(SpringBootCoreAllApplication.class, args);
		BulbService bs=ac.getBean(BulbService.class);
		bs.askBulb();//ye do clss pe deped h to jiska ob chayie use primay kro ok
		System.out.println(bs.askBulb());
		//@primary / @qualifier(ye byname jo componat me or @qualifier dono mein same) koi bhi ak
		
//		System.out.println(ac.getBean(SuryaBulb.class));//scope(value="prototype")
//		System.out.println(ac.getBean(SuryaBulb.class));
//		System.out.println(ac.getBean(LgBulb.class));//scope(value="prototype")
//		System.out.println(ac.getBean(LgBulb.class));
//		System.out.println(ac.getBean(BulbService.class));//scope(value="singleton")ye bydefault rahta h
//		System.out.println(ac.getBean(BulbService.class));
	}

}
