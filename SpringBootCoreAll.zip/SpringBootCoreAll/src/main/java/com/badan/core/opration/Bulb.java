package com.badan.core.opration;

public interface Bulb {
	public abstract String getBulb();
}
