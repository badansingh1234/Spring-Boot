package com.badan.basic.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.badan.basic.model.Person;

public interface PersonRepository extends JpaRepository<Person,Integer> {

}
