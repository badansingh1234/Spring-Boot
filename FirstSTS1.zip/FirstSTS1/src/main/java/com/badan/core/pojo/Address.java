package com.badan.core.pojo;

import org.springframework.stereotype.Component;

@Component
public class Address {
	private Integer hNO;
	private String hName;
	private Long phone;
	public void sethNO(Integer hNO) {
		this.hNO = hNO;
	}
	public void sethName(String hName) {
		this.hName = hName;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Address [hNO=" + hNO + ", hName=" + hName + ", phone=" + phone + "]";
	}
		
}
