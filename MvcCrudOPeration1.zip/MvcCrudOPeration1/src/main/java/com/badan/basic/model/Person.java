package com.badan.basic.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Person {
	@Id
	private Integer no;
	private String name;
	private Float salary;
	 
	public Person() {}	
	public Person(Integer no, String name, Float salary) {
		this.no = no;this.name = name;this.salary = salary;}
	
	public Integer getNo() {
		return no;
	}
	public void setNo(Integer no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getSalary() {
		return salary;
	}
	public void setSalary(Float salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Person [no=" + no + ", name=" + name + ", salary=" + salary + "]";
	}
}
