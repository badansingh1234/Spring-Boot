package com.badan.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestExampleBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestExampleBookApplication.class, args);
	}

}
