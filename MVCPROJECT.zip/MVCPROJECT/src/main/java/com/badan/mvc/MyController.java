package com.badan.mvc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home()
	{
		return "index.jsp";		
	}
	
	@RequestMapping("add")
	public String add(@RequestParam("num1") int num1,@RequestParam("num2")int num2,Model m)
	{
		int num3=num1+num2;
		m.addAttribute("num3",num3);
		return "add.jsp";
	}
	
	/*@RequestMapping("/add")
	public ModelAndView add(@RequestParam("num1") int num1,@RequestParam("num2") int num2)
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("add.jsp");
		int num3=num1+num2;
		mv.addObject("num3",num3);
		return mv;
	}*/
	
/*	@RequestMapping("add")
	public String add(@RequestParam("num1") int num1,@RequestParam("num2") int num2,HttpSession s)
	{
		int num3=num1+num2;
		s.setAttribute("num3", num3);
		return "add.jsp";
	}*/
	
	/*@RequestMapping("add")
	public String add(HttpServletRequest req)
	{
		int num1=Integer.parseInt(req.getParameter("num1"));
		int num2=Integer.parseInt(req.getParameter("num2"));
		int num3=num1+num2;
		HttpSession s=req.getSession();
		s.setAttribute("num3", num3);
		return "add.jsp";
	}*/
}
